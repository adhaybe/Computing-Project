import pickle
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
from flask import Flask, render_template, request
app = Flask(__name__)
@app.route('/')
def home():
	return render_template('master.html')

@app.route('/predict',methods=['POST'])
def predict():
	# load the CountVectorizer
	with open('count.pkl', 'rb') as fid1:
		count = pickle.load(fid1)
	# load the TfidfTransformer
	with open('tfid.pkl', 'rb') as fid2:
		tfid = pickle.load(fid2)
	# load the classifier
	with open('nbclassifier.pkl', 'rb') as fid3:
		clf = pickle.load(fid3)
	if request.method == 'POST':
		Body = request.form['Body']
		punct = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
		nopunc = [char for char in Body if char not in punct]
		nopunc = ''.join(nopunc)
		clean = [word for word in nopunc.split() if word.lower() not in stopwords.words('english')]
		x = np.array(' '.join(clean))
		x=pd.DataFrame(np.reshape(x, (1,1)))[0]
		x=count.transform(x)
		x=tfid.transform(x)
		y_predict = clf.predict(x)
	return render_template('result.html', prediction=y_predict)

if __name__ == '__main__':
	app.run(debug=True)
