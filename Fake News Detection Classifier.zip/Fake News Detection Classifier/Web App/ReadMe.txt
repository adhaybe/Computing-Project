Steps to use the web application:

1. Intsall Pycharm or load Visual studio
2. Open the project folder in that
3. Run app.py file
4. You will see link http://127.0.0.1:5000 so click on it or you can copy and paste on your default browser
5. You will then see the body of text box so you can enter the text accordingly, then click the predict button
6. Finally you will see if the news article is real or fake!!!
